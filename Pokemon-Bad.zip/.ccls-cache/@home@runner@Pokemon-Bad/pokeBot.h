/**
* @author JonnyT-chocomint, yujiroo & Penguinoucy
*/

#include "pokemon.h"

class Bot {
  private:
  int randInt1;
  int randInt2;
  int randInt3;
  int randInt4;

  public:
  void chooseParty() {
    srand(time(NULL));
    this->randInt1 = rand() % 27;
    this->randInt2 = rand() % 27;
    }
  
};