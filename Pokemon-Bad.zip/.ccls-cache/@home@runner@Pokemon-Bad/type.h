/**
* @author JonnyT-chocomint, yujiroo & Penguinoucy
*/

#include "pokemon.h"

class Type {
  private:
    vector<Type> weaknesses;
    vector<Type> resistances;
  private:
    amongus;