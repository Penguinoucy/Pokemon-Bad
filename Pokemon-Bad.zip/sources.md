https://cplusplus.com/reference/thread/this_thread/sleep_for/ (jonathan used this)
https://stackoverflow.com/questions/74637272/typing-effect-in-c (jonathan used this)
https://bulbapedia.bulbagarden.net/wiki/Main_Page (jonathan used this)
Tony
Jeffery (jonathan used this)
Mrs. Strong
https://stackoverflow.com/questions/20326356/how-to-remove-all-the-occurrences-of-a-char-in-c-string (jonathan used this)
https://stackoverflow.com/questions/7786994/c-getline-isnt-waiting-for-input-from-console-when-called-multiple-times (jonathan used this)
https://cplusplus.com/
